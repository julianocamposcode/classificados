let nav = document.querySelector(".links");
let drop = document.querySelector(".dropMenu");
let menu = document.querySelector(".menu");
let back = document.querySelector(".back");
let banner = document.querySelector(".banner");
let news = document.querySelector(".new");
let destaques = document.getElementById("imageList");


menu.addEventListener("click", () => {
    nav.classList.add("show");
    if (banner && news) { none(banner); none(news); }

    back.classList.add("blur");

    let close = document.querySelector(".close");

    close.style.display = 'block'

    close.addEventListener("click", () => {
        nav.classList.remove("show");
        if (banner && news) { block(banner); block(news); }
        back.classList.remove("blur");
    });

    block = (el) => {
        el.style.display = "block";
    };
});

none = (el) => {
    el.style.display = "none";
};

function scroll() {
    if (scrollY > 0) {
        nav.classList.add("style_nav");
        drop.classList.add("style_nav");
    } else {
        nav.classList.remove("style_nav");
        drop.classList.remove("style_nav");
    }
}




let banco_dados;

const resquisicao = indexedDB.open("productDB", 1);

resquisicao.onsuccess = (event) => {
    banco_dados = event.target.result;
    loadProducts();
};

function loadProducts() {
    const transaction = banco_dados.transaction(["products"], "readonly");
    const objectStore = transaction.objectStore("products");
    const resquisicao = objectStore.getAll();

    resquisicao.onsuccess = (event) => {
        if (destaques) {
            destaques.innerHTML = ""; // Limpa a lista antes de adicionar os itens
            const products = event.target.result;

            if (products.slice(-3).length > 0) {
                products.slice(-3).forEach((item) => {
                    let card = document.createElement("div")
                    card.classList.add('card');
                    let img = document.createElement("img");
                    img.classList.add('img')
                    let text = document.createElement("p");
                    text.classList.add('titulo')
                    let price = document.createElement("p");
                    price.classList.add('valor')

                    img.src = item.imageData;
                    text.textContent = item.textData;
                    price.textContent = `Preço: R$ ${item.priceData}`;

                    // let deleteButton = document.createElement("button");
                    // deleteButton.classList.add('option')
                    // deleteButton.innerHTML = '🗑️'
                    // deleteButton.onclick = () => deleteProduct(item.id);

                    let butonDetalhe = document.createElement('button')
                    butonDetalhe.classList = 'buton_detalhe'

                    let p_det = document.createElement('p')
                    p_det.innerText = 'Detalhes +'
                    butonDetalhe.appendChild(p_det)

                    card.appendChild(img);
                    card.appendChild(text);
                    card.appendChild(price);
                    card.appendChild(butonDetalhe);
                    destaques.appendChild(card);
                });
            }
        }
    };

    resquisicao.onerror = (event) => {
        console.error("Erro ao carregar os produtos do IndexedDB", event);
    };
}
window.onload = loadProducts;
